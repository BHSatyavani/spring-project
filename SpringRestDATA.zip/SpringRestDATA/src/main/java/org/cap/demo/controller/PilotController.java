package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.dao.IPilotDao;
import org.cap.demo.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PilotController {
	
	@Autowired
	private IPilotDao pilotDao;

	
	@GetMapping("/pilotsinfo")
	public ResponseEntity<List<Pilot>> getAllPilotsInfo(){
		List<Pilot> pilots= pilotDao.getAllPilotsInfo();
		if(pilots.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots(){
		List<Pilot> pilots= pilotDao.findAll();
		if(pilots.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@GetMapping("/certifiedpilots/{certified}")
	public ResponseEntity<List<Pilot>> getAllCertifiedPilots(
			@PathVariable("certified")boolean certified){
		List<Pilot> pilots= pilotDao.findByIsCertified(certified);
		if(pilots.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	
	@GetMapping("/pilots/{minsal}/{maxsal}")
	public ResponseEntity<List<Pilot>> getSalariedPilots(
			@PathVariable("minsal")double minsal,
			@PathVariable("maxsal") double maxsal){
		List<Pilot> pilots= pilotDao.getAllPilots(minsal, maxsal);
		if(pilots.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	@GetMapping("/pilotnames")
	public ResponseEntity<List<String>> getSalariedPilots(){
		List<String> pilots= pilotDao.getAllNames();
		if(pilots.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<String>>(pilots, HttpStatus.OK);
	}
	
	
	@GetMapping("/pilotfirstnames")
	public ResponseEntity<List<String>> getFirstName(){
		List<String> pilots= pilotDao.getFirstNames();
		if(pilots.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<String>>(pilots, HttpStatus.OK);
	}
	
	
}
