package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@RequestMapping(value="/validateLogin",method=RequestMethod.POST)
	public String validateLogin(
			@RequestParam("username")String userName,
			@RequestParam("password")String pwd,
			ModelMap map) {
		
		if(userName.equals("Tom")&&pwd.equals("tom123")) {
			System.out.println("hi tom");
			map.addAttribute("userName",userName);
			return "success";

		}
		return "fail";
						
	}
} 