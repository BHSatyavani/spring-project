package org.cap.controller;

import org.cap.model.Pilot;
import org.cap.util.PilotUtil;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class PilotController {

	@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	public String savePilotDetails(@ModelAttribute("pilot")Pilot pilot) {
		System.out.println(pilot);
		return "redirect:/success";
	}
	@RequestMapping(value="/success")
	public String pilotPage(ModelMap map) {
		map.addAttribute("pilot",new Pilot());
		map.addAttribute("cities",PilotUtil.getAllCities());
		return "success";
	}
}
