package org.cap.model;

import java.sql.Date;

public class Pilot {
	//@Range(min=1000,max=10000,message="PilotId should be between 1000 and 10000")
	private int pilotId;
	
	
	//@NotEmpty(message="Please enter firstName")
	private String firstName;
	private String lastName;
	private String address;
	private String gender;
	private boolean isCertified;
	private double maxCrusing;
	
	
	/*@Email(message="please enter valid email Id" )
	@NotEmpty(message="please enter email Id" )
	private String email;*/
	
	//@Min(value=100000,message="Salary min should be 1Lak")
	private double salary;
	
	//@Future(message="Date of Joining")
	//@DateTimeFormat(pattern="dd-MMM-yyyy")
	private Date dateOfJoining;
	private String cities;
	
	public Pilot() {
		super();
	}

	public Pilot(int pilotId, String firstName, String lastName, String address, String gender, boolean isCertified,
			double maxCrusing, double salary, Date dateOfJoining, String cities) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gender = gender;
		this.isCertified = isCertified;
		this.maxCrusing = maxCrusing;
		this.salary = salary;
		this.dateOfJoining = dateOfJoining;
		this.cities = cities;
	}

	public int getPilotId() {
		return pilotId;
	}

	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isCertified() {
		return isCertified;
	}

	public void setCertified(boolean certified) {
		this.isCertified = certified;
	}

	public double getMaxCrusing() {
		return maxCrusing;
	}

	public void setMaxCrusing(double maxCrusing) {
		this.maxCrusing = maxCrusing;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getCities() {
		return cities;
	}

	public void setCities(String cities) {
		this.cities = cities;
	}

	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", gender=" + gender + ", isCertified=" + isCertified + ", maxCrusing=" + maxCrusing
				+ ", salary=" + salary + ", dateOfJoining=" + dateOfJoining + ", cities=" + cities + "]";
	}

	
}
