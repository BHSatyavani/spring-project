package org.cap.util;

import java.util.ArrayList;
import java.util.List;

public class PilotUtil {

	public static List<String> getAllCities(){
		
		List<String> cities=new ArrayList<>();
		cities.add("Hyderabad");
		cities.add("Chennai");
		cities.add("Banglore");
		cities.add("Mumbai");
		cities.add("Bowenpally");
		cities.add("Secunderabad");
		return cities;
		
	}
	
	
}
