package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;
import org.cap.model.Aircraft;
import org.cap.model.City;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("pilotService")
public class PilotServiceImpl implements IPilotService{
	@Autowired
    private IPilotDao pilotDao;
	@Override
	public void savePilot(Pilot pilot) {
		
		pilotDao.savePilot(pilot);
	}
	@Override
	public List<Pilot> getPilotDetails() {
		return pilotDao.getPilotDetails();
	}
	@Override
	public void deletePilot(Integer pilotId) {
	pilotDao.deletePilot(pilotId);
		
	}
	@Override
	public Pilot updatePilot(Pilot p) {
	
		return pilotDao.updatePilot(p);
	}
	@Override
	public Pilot getPiotById(Integer pilotId) {
		return pilotDao.getPiotById(pilotId);
	}
	@Override
	public List<City> getAllCities() {
		
		return pilotDao.getAllCities();
	}
	@Override
	public boolean addPilotCertification(Integer pilotId,String aircraftId) {
		
		return pilotDao.addPilotCertification(pilotId,aircraftId);
	}
	@Override
	public List<Aircraft> getAircraft() {
		
		return pilotDao.getAircraft();
	}
	@Override
	public List<Aircraft> getOtherAircraft(Integer pilotId) {
		
		return pilotDao.getOtherAircraft(pilotId);
	}

}
